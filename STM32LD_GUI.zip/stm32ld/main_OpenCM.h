// Portable types

#ifndef __OPENCM_MAIN_H_
#define __OPENCM_MAIN_H_




int OpenCM_main( int argc, const char **argv );


#endif

